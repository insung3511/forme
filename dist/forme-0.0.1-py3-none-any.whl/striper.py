def striper(input_list):
    return_list = []
    for val in input_list:
        return_list.append(val.strip())
    return return_list
