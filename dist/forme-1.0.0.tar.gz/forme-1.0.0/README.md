# For me Python Module Package

I made a python module that I usally use. That's it. 

## compare_checker.py

Just compare the two input lists, are shape is same.